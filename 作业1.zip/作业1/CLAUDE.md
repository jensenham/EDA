# CLAUDE.md

本文件为Claude Code (claude.ai/code) 在RISC-V RTL自动生成项目中提供指导。

## 项目概述

这是一个基于Claude Code的RISC-V模块RTL自动生成Agent项目。目标是通过配置Rules、Skills和Hooks，构建一条从自然语言到可仿真RTL的全自动流水线，用于生成并验证RISC-V功能子模块。

## 全自动目标

用户只需在Claude Code终端输入一句自然语言需求，Agent自动完成：
1. 需求解析
2. Chisel代码生成
3. firtool编译
4. Verilator语法检查
5. Testbench生成与仿真
6. 验证报告输出

## 项目结构

```
作业1/
├── .claude/                    # Claude Code配置文件
│   ├── rules/                 # 规则定义
│   ├── skills/               # 技能模板
│   └── hooks/                # 钩子脚本
├── src/                      # 源代码
│   ├── chisel/              # Chisel源码
│   ├── verilog/             # 生成的Verilog
│   └── testbench/           # 测试平台
├── sim/                     # 仿真相关
│   ├── logs/               # 仿真日志
│   └── scripts/            # 仿真脚本
├── docs/                    # 文档
└── build.sbt               # Scala构建文件
```

## 技术栈

- **Chisel**: 硬件构造语言，用于生成RTL
- **sbt**: Scala构建工具
- **firtool**: FIRRTL编译器，将Chisel输出为Verilog
- **Verilator**: RTL语法检查与仿真工具
- **RV32I**: RISC-V 32位基础整数指令集

## 接口规范

所有生成的RISC-V模块必须符合RV32I标准：
- 32位数据宽度
- 标准控制信号（clock, reset, valid, ready等）
- 模块化设计，便于集成

## 全自动流水线说明

### 1. 需求解析阶段
- 使用Skills解析用户自然语言需求
- 必要时与用户交互澄清需求
- 生成规范化的需求文档

### 2. Chisel代码生成
- 根据需求生成符合规范的Chisel代码
- 代码应包含完整的模块接口和功能实现
- 遵循Chisel最佳实践

### 3. 编译转换
- 自动执行`sbt compile`编译Chisel代码
- 使用`firtool`将FIRRTL转换为Verilog
- 输出到`src/verilog/`目录

### 4. 语法检查
- 使用`verilator --lint-only`检查生成的Verilog
- 自动修复发现的语法问题
- 生成语法检查报告

### 5. Testbench生成
- 根据模块功能自动生成合适的测试用例
- 生成SystemVerilog测试平台
- 包含完整的测试激励和检查机制

### 6. 仿真验证
- 执行仿真并收集结果
- 自动生成验证报告
- 报告格式符合要求

## 文件路径规范

- Chisel源码: `src/chisel/<模块名>.scala`
- 生成的Verilog: `src/verilog/<模块名>.v`
- 测试平台: `src/testbench/<模块名>_tb.sv`
- 仿真脚本: `sim/scripts/sim_<模块名>.sh`
- 仿真日志: `sim/logs/sim_<模块名>.log`
- 验证报告: `docs/verification_<模块名>.md`

## 验证标准

### 语法检查标准
```bash
verilator --lint-only src/verilog/*.v
```
- 无ERROR输出
- 允许WARNING，但需在报告中说明原因

### 功能仿真标准
仿真结果日志格式：
```
[TEST 1] ADD: a=5 b=3 | expect=8 got=8 | PASS
[TEST 2] SUB: a=10 b=7 | expect=3 got=3 | PASS
[TEST 3] AND: a=0xFF b=0x0F | expect=0x0F got=0x0F | PASS
...
RESULT: PASSED X/X tests
```

## 工具要求

1. Node.js 18+ 及 Claude Code CLI
2. Java 11+ 及 sbt
3. firtool（FIRRTL编译器）
4. Verilator >= 4.200

## API配置

Claude Code通过环境变量配置API：
```bash
export ANTHROPIC_BASE_URL=<课程提供地址>
export ANTHROPIC_API_KEY=<课程提供密钥>
```

## 注意事项

1. 安全：不得提交API Key到代码仓库
2. 规范：模块接口需对齐RV32I规范
3. 学术诚信：报告须自主撰写，代码和配置可参考公开资料但须注明来源