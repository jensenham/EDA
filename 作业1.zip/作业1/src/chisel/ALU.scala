package riscv

import chisel3._
import chisel3.util._

/**
  * RISC-V RV32I ALU模块
  * 严格按照作业要求生成：支持ADD/SUB/AND/OR/XOR/SLT，含zero标志位
  * 生成时间: $(date)
  */
class ALU extends Module {
  val io = IO(new Bundle {
    // 32位操作数输入 - RV32I标准
    val a = Input(UInt(32.W))
    val b = Input(UInt(32.W))

    // 操作码输入 (3位足够，但使用4位便于扩展)
    val alu_op = Input(UInt(4.W))

    // 32位结果输出 - RV32I标准
    val result = Output(UInt(32.W))

    // zero标志位输出 - 作业要求
    val zero = Output(Bool())
  })

  // 操作码定义 - 对应6种操作
  val ALU_ADD = 0.U(4.W)
  val ALU_SUB = 1.U(4.W)
  val ALU_AND = 2.U(4.W)
  val ALU_OR  = 3.U(4.W)
  val ALU_XOR = 4.U(4.W)
  val ALU_SLT = 5.U(4.W)  // 有符号比较

  // 计算中间结果
  val add_result = io.a +& io.b           // 带进位的加法
  val sub_result = io.a -& io.b           // 带借位的减法
  val and_result = io.a & io.b            // 按位与
  val or_result  = io.a | io.b            // 按位或
  val xor_result = io.a ^ io.b            // 按位异或

  // SLT: Set Less Than - 有符号比较
  val slt_result = Mux(io.a.asSInt < io.b.asSInt, 1.U(32.W), 0.U(32.W))

  // 根据操作码选择结果 - 使用MuxCase替代MuxLookup
  io.result := MuxCase(0.U(32.W), Seq(
    (io.alu_op === ALU_ADD) -> add_result(31, 0),  // 取低32位
    (io.alu_op === ALU_SUB) -> sub_result(31, 0),
    (io.alu_op === ALU_AND) -> and_result,
    (io.alu_op === ALU_OR)  -> or_result,
    (io.alu_op === ALU_XOR) -> xor_result,
    (io.alu_op === ALU_SLT) -> slt_result
  ))

  // zero标志位：当结果为0时置位
  io.zero := io.result === 0.U

  // 可选的溢出标志（扩展功能）
  // val overflow = Mux(io.alu_op === ALU_ADD, add_result(32),
  //                 Mux(io.alu_op === ALU_SUB, sub_result(32), false.B))
}

/**
  * ALU测试对象 - 生成Verilog
  */
object ALU extends App {
  println("生成ALU Verilog代码...")
  chisel3.Driver.execute(Array("--target-dir", "generated"), () => new ALU())
}
