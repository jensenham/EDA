`timescale 1ns/1ps

module ALU_tb;
  // 时钟和复位信号
  reg clk;
  reg reset;

  // DUT接口
  reg [31:0] a;
  reg [31:0] b;
  reg [3:0] alu_op;
  wire [31:0] result;
  wire zero;

  // 测试结果
  integer test_count = 0;
  integer pass_count = 0;
  integer fail_count = 0;

  // 实例化ALU
  ALU dut (
    .clock(clk),
    .reset(reset),
    .io_a(a),
    .io_b(b),
    .io_alu_op(alu_op),
    .io_result(result),
    .io_zero(zero)
  );

  // 时钟生成：100MHz
  always #5 clk = ~clk;

  // 操作码定义
  localparam [3:0]
    ALU_ADD = 4'd0,
    ALU_SUB = 4'd1,
    ALU_AND = 4'd2,
    ALU_OR  = 4'd3,
    ALU_XOR = 4'd4,
    ALU_SLT = 4'd5;

  // 测试任务：执行单个操作并检查结果
  task test_operation;
    input [3:0] op;
    input [31:0] input_a;
    input [31:0] input_b;
    input [31:0] expected;
    reg [31:0] actual;
    reg zero_expected;
    string op_name;
    begin
      test_count = test_count + 1;

      // 设置操作数
      a = input_a;
      b = input_b;
      alu_op = op;

      // 等待一个时钟周期
      @(posedge clk);
      #1;

      actual = result;
      zero_expected = (expected == 32'd0);

      // 根据操作码设置操作名称
      case (op)
        ALU_ADD: op_name = "ADD";
        ALU_SUB: op_name = "SUB";
        ALU_AND: op_name = "AND";
        ALU_OR:  op_name = "OR";
        ALU_XOR: op_name = "XOR";
        ALU_SLT: op_name = "SLT";
        default: op_name = "UNKNOWN";
      endcase

      // 检查结果
      if (actual === expected && zero === zero_expected) begin
        $display("[TEST %0d] %s: a=%0d b=%0d | expect=%0d got=%0d | zero_expect=%b zero_got=%b | PASS",
                 test_count, op_name, input_a, input_b, expected, actual, zero_expected, zero);
        pass_count = pass_count + 1;
      end else begin
        $display("[TEST %0d] %s: a=%0d b=%0d | expect=%0d got=%0d | zero_expect=%b zero_got=%b | FAIL",
                 test_count, op_name, input_a, input_b, expected, actual, zero_expected, zero);
        fail_count = fail_count + 1;
      end
    end
  endtask

  // 主测试序列
  initial begin
    // 初始化
    clk = 0;
    reset = 1;
    a = 32'd0;
    b = 32'd0;
    alu_op = ALU_ADD;

    // 应用复位
    #20 reset = 0;
    #10;

    $display("=== ALU功能测试开始 ===");

    // 测试1: ADD操作
    test_operation(ALU_ADD, 32'd5, 32'd3, 32'd8);      // 5 + 3 = 8
    test_operation(ALU_ADD, 32'd100, 32'd200, 32'd300); // 100 + 200 = 300
    test_operation(ALU_ADD, 32'hFFFFFFFF, 32'd1, 32'd0); // 溢出测试

    // 测试2: SUB操作
    test_operation(ALU_SUB, 32'd10, 32'd7, 32'd3);     // 10 - 7 = 3
    test_operation(ALU_SUB, 32'd50, 32'd50, 32'd0);    // 50 - 50 = 0
    test_operation(ALU_SUB, 32'd0, 32'd1, 32'hFFFFFFFF); // 0 - 1 = -1

    // 测试3: AND操作
    test_operation(ALU_AND, 32'hFF00FF00, 32'h0F0F0F0F, 32'h0F000F00);
    test_operation(ALU_AND, 32'h12345678, 32'h87654321, 32'h02244220);
    test_operation(ALU_AND, 32'hFFFFFFFF, 32'h00000000, 32'd0);

    // 测试4: OR操作
    test_operation(ALU_OR, 32'hFF00FF00, 32'h00FF00FF, 32'hFFFFFFFF);
    test_operation(ALU_OR, 32'h12345678, 32'h87654321, 32'h97755779);
    test_operation(ALU_OR, 32'd0, 32'd0, 32'd0);

    // 测试5: XOR操作
    test_operation(ALU_XOR, 32'hFFFF0000, 32'h0000FFFF, 32'hFFFFFFFF);
    test_operation(ALU_XOR, 32'h12345678, 32'h12345678, 32'd0); // 相同数异或为0
    test_operation(ALU_XOR, 32'hA5A5A5A5, 32'h5A5A5A5A, 32'hFFFFFFFF);

    // 测试6: SLT操作（有符号比较）
    test_operation(ALU_SLT, 32'd5, 32'd10, 32'd1);      // 5 < 10 => 1
    test_operation(ALU_SLT, 32'd10, 32'd5, 32'd0);      // 10 < 5 => 0
    test_operation(ALU_SLT, 32'hFFFFFFFF, 32'd0, 32'd1); // -1 < 0 => 1
    test_operation(ALU_SLT, 32'd0, 32'hFFFFFFFF, 32'd0); // 0 < -1 => 0
    test_operation(ALU_SLT, 32'd100, 32'd100, 32'd0);   // 相等 => 0

    // 测试7: zero标志位测试
    test_operation(ALU_SUB, 32'd100, 32'd100, 32'd0);   // 结果应为0，zero=1
    test_operation(ALU_XOR, 32'd123, 32'd123, 32'd0);   // 结果应为0，zero=1
    test_operation(ALU_ADD, 32'd1, 32'd2, 32'd3);       // 结果非0，zero=0

    // 显示测试结果
    $display("\n=== 测试结果 ===");
    $display("总测试数: %0d", test_count);
    $display("通过: %0d", pass_count);
    $display("失败: %0d", fail_count);

    if (fail_count == 0) begin
      $display("RESULT: PASSED %0d/%0d tests", pass_count, test_count);
    end else begin
      $display("RESULT: FAILED %0d/%0d tests", fail_count, test_count);
    end

    // 结束仿真
    #100;
    $finish;
  end

  // 波形文件生成（用于调试）
  initial begin
    $dumpfile("sim_build/ALU_tb.vcd");
    $dumpvars(0, ALU_tb);
  end

endmodule