#include "VALU.h"
#include "verilated.h"
#include <iostream>
#include <cstdlib>

int main(int argc, char** argv) {
    Verilated::commandArgs(argc, argv);

    VALU* dut = new VALU;

    // 初始化
    dut->reset = 1;
    dut->clock = 0;

    // 释放复位
    for (int i = 0; i < 10; i++) {
        dut->clock = !dut->clock;
        dut->eval();
    }
    dut->reset = 0;

    // 简单功能测试
    std::cout << "ALU简单功能测试开始..." << std::endl;

    // 测试1: ADD操作
    dut->io_a = 5;
    dut->io_b = 3;
    dut->io_alu_op = 0;  // ADD
    dut->clock = !dut->clock;
    dut->eval();
    std::cout << "ADD测试: 5 + 3 = " << dut->io_result << std::endl;

    // 测试2: SUB操作
    dut->io_a = 10;
    dut->io_b = 7;
    dut->io_alu_op = 1;  // SUB
    dut->clock = !dut->clock;
    dut->eval();
    std::cout << "SUB测试: 10 - 7 = " << dut->io_result << std::endl;

    // 测试3: AND操作
    dut->io_a = 0xFF;
    dut->io_b = 0x0F;
    dut->io_alu_op = 2;  // AND
    dut->clock = !dut->clock;
    dut->eval();
    std::cout << "AND测试: 0xFF & 0x0F = 0x" << std::hex << dut->io_result << std::dec << std::endl;

    // 测试4: OR操作
    dut->io_a = 0xF0;
    dut->io_b = 0x0F;
    dut->io_alu_op = 3;  // OR
    dut->clock = !dut->clock;
    dut->eval();
    std::cout << "OR测试: 0xF0 | 0x0F = 0x" << std::hex << dut->io_result << std::dec << std::endl;

    // 测试5: XOR操作
    dut->io_a = 0xFF;
    dut->io_b = 0xFF;
    dut->io_alu_op = 4;  // XOR
    dut->clock = !dut->clock;
    dut->eval();
    std::cout << "XOR测试: 0xFF ^ 0xFF = 0x" << std::hex << dut->io_result << std::dec << std::endl;

    // 测试6: SLT操作
    dut->io_a = 5;
    dut->io_b = 10;
    dut->io_alu_op = 5;  // SLT
    dut->clock = !dut->clock;
    dut->eval();
    std::cout << "SLT测试: 5 < 10 ? " << dut->io_result << std::endl;

    // 测试7: zero标志位
    dut->io_a = 5;
    dut->io_b = 5;
    dut->io_alu_op = 1;  // SUB (5-5=0)
    dut->clock = !dut->clock;
    dut->eval();
    std::cout << "ZERO测试: 5 - 5 = " << dut->io_result << ", zero = " << (dut->io_zero ? "true" : "false") << std::endl;

    // 运行一些时钟周期
    for (int i = 0; i < 20; i++) {
        dut->clock = !dut->clock;
        dut->eval();
    }

    std::cout << "ALU仿真完成" << std::endl;

    delete dut;
    return 0;
}