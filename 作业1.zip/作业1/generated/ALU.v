// 模拟生成的ALU Verilog代码
// 实际环境中应由firtool从Chisel生成

module ALU(
  input         clock,
  input         reset,
  input  [31:0] io_a,
  input  [31:0] io_b,
  input  [3:0]  io_alu_op,
  output [31:0] io_result,
  output        io_zero
);

  // 模拟实现
  reg [31:0] result_reg;
  reg zero_reg;

  always @(posedge clock) begin
    if (reset) begin
      result_reg <= 32'h0;
      zero_reg <= 1'b0;
    end else begin
      case (io_alu_op)
        4'd0: result_reg <= io_a + io_b;      // ADD
        4'd1: result_reg <= io_a - io_b;      // SUB
        4'd2: result_reg <= io_a & io_b;      // AND
        4'd3: result_reg <= io_a | io_b;      // OR
        4'd4: result_reg <= io_a ^ io_b;      // XOR
        4'd5: result_reg <= (io_a < io_b) ? 32'd1 : 32'd0; // SLT
        default: result_reg <= 32'h0;
      endcase
      zero_reg <= (result_reg == 32'h0);
    end
  end

  assign io_result = result_reg;
  assign io_zero = zero_reg;

endmodule
