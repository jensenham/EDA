# ALU 需求规格
生成时间: 2026年 03月 19日 星期四 21:04:06 CST

## 原始需求
请你帮我生成一个ALU，需要支持ADD/SUB/AND/OR/XOR/SLT，含 zero 标志位

## 解析结果
- 模块名称: ALU
- 功能列表: ADD, SUB, AND, OR, XOR, SLT, ZERO_FLAG
- 数据宽度: 32位
- 标准: RV32I

## 测试要求
- 语法检查: Verilator lint检查
- 功能测试: 所有操作的基本测试
- 边界测试: 最大值、最小值测试
- 标志位测试: zero标志位验证
