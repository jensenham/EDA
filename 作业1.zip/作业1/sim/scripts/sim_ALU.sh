#!/bin/bash
# ALU模块仿真脚本

set -e  # 遇到错误时退出

echo "=== ALU模块仿真开始 ==="

# 项目根目录
PROJECT_ROOT="/home/loasic/EDA/作业1"
cd "$PROJECT_ROOT"

# 模块名称
MODULE_NAME="ALU"

# 1. 检查必要文件
echo "1. 检查必要文件..."
REQUIRED_FILES=(
    "src/chisel/$MODULE_NAME.scala"
    "src/verilog/$MODULE_NAME.v"
    "src/testbench/${MODULE_NAME}_tb.sv"
)

for file in "${REQUIRED_FILES[@]}"; do
    if [ ! -f "$file" ]; then
        echo "错误：缺少文件 $file"
        exit 1
    fi
    echo "  ✓ $file"
done

# 2. 语法检查
echo "2. 执行语法检查..."
LINT_LOG="sim/logs/lint_${MODULE_NAME}.log"
verilator --lint-only \
    --Wall \
    --Wno-style \
    "src/verilog/$MODULE_NAME.v" \
    2>&1 | tee "$LINT_LOG"

# 检查是否有错误
if grep -q -E "Error|ERROR" "$LINT_LOG"; then
    echo "错误：发现语法错误"
    grep -E "Error|ERROR" "$LINT_LOG"
    exit 1
else
    echo "  ✓ 语法检查通过"
fi

# 3. 准备仿真目录
echo "3. 准备仿真目录..."
SIM_BUILD_DIR="sim_build/${MODULE_NAME}"
mkdir -p "$SIM_BUILD_DIR"
cd "$SIM_BUILD_DIR"

# 4. 编译仿真模型
echo "4. 编译仿真模型..."
COMPILE_LOG="compile.log"
verilator --cc --exe \
    --trace \
    --assert \
    -Wall \
    -Wno-style \
    "../../src/verilog/$MODULE_NAME.v" \
    "../../src/testbench/${MODULE_NAME}_tb.cpp" \
    -o "${MODULE_NAME}_sim" \
    2>&1 | tee "$COMPILE_LOG"

if [ $? -ne 0 ]; then
    echo "错误：编译失败"
    exit 1
fi
echo "  ✓ 编译成功"

# 5. 执行仿真
echo "5. 执行仿真..."
SIM_LOG="../../sim/logs/sim_${MODULE_NAME}.log"
./"${MODULE_NAME}_sim" 2>&1 | tee "$SIM_LOG"

# 6. 分析结果
echo "6. 分析仿真结果..."
if grep -q "RESULT: PASSED" "$SIM_LOG"; then
    echo "  ✓ 仿真通过"
    RESULT="PASS"
else
    echo "  ✗ 仿真失败"
    RESULT="FAIL"
fi

# 7. 生成简要报告
echo "7. 生成仿真报告..."
REPORT_FILE="../../sim/logs/sim_report_${MODULE_NAME}.md"
{
    echo "# ALU仿真报告"
    echo "生成时间: $(date)"
    echo ""
    echo "## 执行摘要"
    echo "- 模块: $MODULE_NAME"
    echo "- 仿真时间: $(date)"
    echo "- 结果: $RESULT"
    echo ""
    echo "## 文件清单"
    echo "- Chisel源码: \`src/chisel/$MODULE_NAME.scala\`"
    echo "- Verilog源码: \`src/verilog/$MODULE_NAME.v\`"
    echo "- 测试平台: \`src/testbench/${MODULE_NAME}_tb.sv\`"
    echo "- 仿真日志: \`$SIM_LOG\`"
    echo ""
    echo "## 语法检查结果"
    echo "状态: $(grep -q -E "Error|ERROR" "../../$LINT_LOG" && echo "失败" || echo "通过")"
    echo ""
    echo "## 仿真结果摘要"
    tail -20 "$SIM_LOG" | grep -E "TEST|RESULT|===|通过|失败"
    echo ""
    echo "## 详细日志"
    echo "### 语法检查日志"
    echo "\`\`\`"
    head -50 "../../$LINT_LOG"
    echo "\`\`\`"
    echo ""
    echo "### 仿真日志"
    echo "\`\`\`"
    tail -50 "$SIM_LOG"
    echo "\`\`\`"
} > "$REPORT_FILE"

echo ""
echo "=== 仿真完成 ==="
echo "仿真结果: $RESULT"
echo "详细报告: $REPORT_FILE"
echo "仿真日志: $SIM_LOG"

if [ "$RESULT" = "FAIL" ]; then
    exit 1
else
    exit 0
fi