`timescale 1ns/1ps

module alu_tb;
  // 测试信号
  reg clk;
  reg rst_n;
  reg [31:0] a;
  reg [31:0] b;
  reg [3:0] alu_op;
  wire [31:0] result;
  wire zero;

  // 测试统计
  integer test_count = 0;
  integer pass_count = 0;
  integer fail_count = 0;

  // 实例化ALU
  ALU dut (
    .clock(clk),
    .reset(~rst_n),
    .io_a(a),
    .io_b(b),
    .io_alu_op(alu_op),
    .io_result(result),
    .io_zero(zero)
  );

  // 时钟生成：100MHz
  always #5 clk = ~clk;

  // 操作码定义
  localparam [3:0]
    OP_ADD = 4'd0,
    OP_SUB = 4'd1,
    OP_AND = 4'd2,
    OP_OR  = 4'd3,
    OP_XOR = 4'd4,
    OP_SLT = 4'd5;

  // 单个测试任务
  task test_op;
    input [3:0] op;
    input [31:0] a_val;
    input [31:0] b_val;
    input [31:0] expected;
    reg [31:0] actual;
    reg zero_expected;
    string op_name;
    begin
      test_count = test_count + 1;

      // 设置输入
      a = a_val;
      b = b_val;
      alu_op = op;

      // 等待一个时钟周期
      @(posedge clk);
      #1;

      actual = result;
      zero_expected = (expected == 32'd0);

      // 操作名称
      case (op)
        OP_ADD: op_name = "ADD";
        OP_SUB: op_name = "SUB";
        OP_AND: op_name = "AND";
        OP_OR:  op_name = "OR";
        OP_XOR: op_name = "XOR";
        OP_SLT: op_name = "SLT";
        default: op_name = "UNKNOWN";
      endcase

      // 检查结果
      if (actual === expected && zero === zero_expected) begin
        $display("[TEST %0d] %s: a=%0d b=%0d | expect=%0d got=%0d | PASS",
                 test_count, op_name, a_val, b_val, expected, actual);
        pass_count = pass_count + 1;
      end else begin
        $display("[TEST %0d] %s: a=%0d b=%0d | expect=%0d got=%0d | zero_expect=%b zero_got=%b | FAIL",
                 test_count, op_name, a_val, b_val, expected, actual, zero_expected, zero);
        fail_count = fail_count + 1;
      end
    end
  endtask

  // 主测试序列
  initial begin
    // 初始化
    clk = 0;
    rst_n = 0;
    a = 32'd0;
    b = 32'd0;
    alu_op = OP_ADD;

    // 复位
    #20 rst_n = 1;
    #10;

    $display("=== ALU功能测试开始 ===");
    $display("严格按照作业要求格式输出");

    // 测试1: ADD操作 - 作业示例
    test_op(OP_ADD, 32'd5, 32'd3, 32'd8);        // 5 + 3 = 8
    test_op(OP_ADD, 32'd10, 32'd20, 32'd30);     // 10 + 20 = 30
    test_op(OP_ADD, 32'hFFFFFFFF, 32'd1, 32'd0); // 溢出测试

    // 测试2: SUB操作 - 作业示例
    test_op(OP_SUB, 32'd10, 32'd7, 32'd3);       // 10 - 7 = 3
    test_op(OP_SUB, 32'd50, 32'd50, 32'd0);      // 50 - 50 = 0

    // 测试3: AND操作 - 作业示例
    test_op(OP_AND, 32'hFF, 32'h0F, 32'h0F);     // 0xFF & 0x0F = 0x0F
    test_op(OP_AND, 32'h1234, 32'h5678, 32'h1230);

    // 测试4: OR操作
    test_op(OP_OR, 32'hF0, 32'h0F, 32'hFF);      // 0xF0 | 0x0F = 0xFF
    test_op(OP_OR, 32'h1100, 32'h0011, 32'h1111);

    // 测试5: XOR操作
    test_op(OP_XOR, 32'hFF, 32'hFF, 32'h00);     // 相同数异或为0
    test_op(OP_XOR, 32'hA5, 32'h5A, 32'hFF);

    // 测试6: SLT操作
    test_op(OP_SLT, 32'd5, 32'd10, 32'd1);       // 5 < 10 => 1
    test_op(OP_SLT, 32'd10, 32'd5, 32'd0);       // 10 < 5 => 0
    test_op(OP_SLT, 32'hFFFFFFFF, 32'd0, 32'd1); // -1 < 0 => 1

    // 测试7: zero标志位测试
    test_op(OP_SUB, 32'd100, 32'd100, 32'd0);    // 结果0 => zero=1
    test_op(OP_ADD, 32'd1, 32'd2, 32'd3);        // 结果非0 => zero=0

    // 显示最终结果 - 严格按作业格式
    $display("");
    $display("=== 测试结果 ===");
    $display("总测试数: %0d", test_count);
    $display("通过: %0d", pass_count);
    $display("失败: %0d", fail_count);
    $display("");

    if (fail_count == 0) begin
      $display("RESULT: PASSED %0d/%0d tests", pass_count, test_count);
    end else begin
      $display("RESULT: FAILED %0d/%0d tests", fail_count, test_count);
    end

    // 结束仿真
    #100;
    $finish;
  end

  // 波形文件
  initial begin
    $dumpfile("sim_build/alu_tb.vcd");
    $dumpvars(0, alu_tb);
  end

endmodule
