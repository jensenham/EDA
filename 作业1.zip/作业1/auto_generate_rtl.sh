#!/bin/bash
# RTL自动生成脚本
# 根据用户输入的自然语言需求，全自动生成RTL和验证报告

set -e  # 遇到错误时退出

echo "=== RISC-V RTL自动生成系统 ==="
echo "版本: 1.0"
echo "时间: $(date)"
echo ""

# 项目根目录
PROJECT_ROOT="/home/loasic/EDA/作业1"
cd "$PROJECT_ROOT"

# 创建必要的目录
mkdir -p src/{chisel,verilog,testbench}
mkdir -p sim/{logs,scripts}
mkdir -p docs

# 1. 需求输入
echo "1. 请输入您的RTL需求（自然语言）："
echo "   例如：'请你帮我生成一个ALU，需要支持ADD/SUB/AND/OR/XOR/SLT，含 zero 标志位'"
echo ""
read -p "> " USER_INPUT

if [ -z "$USER_INPUT" ]; then
    echo "错误：需求不能为空"
    exit 1
fi

echo ""
echo "需求已接收: $USER_INPUT"
echo ""

# 2. 需求解析
echo "2. 解析需求..."
# 这里可以集成AI进行自然语言解析
# 暂时使用简单的关键词匹配

MODULE_NAME=""
FUNCTIONS=()

# 提取模块名称
if echo "$USER_INPUT" | grep -qi "ALU"; then
    MODULE_NAME="ALU"
    echo "  检测到模块: ALU"
elif echo "$USER_INPUT" | grep -qi "寄存器"; then
    MODULE_NAME="RegisterFile"
    echo "  检测到模块: 寄存器文件"
else
    MODULE_NAME="RISC_V_Module"
    echo "  使用默认模块名称: $MODULE_NAME"
fi

# 提取功能列表
if echo "$USER_INPUT" | grep -qi "ADD"; then
    FUNCTIONS+=("ADD")
fi
if echo "$USER_INPUT" | grep -qi "SUB"; then
    FUNCTIONS+=("SUB")
fi
if echo "$USER_INPUT" | grep -qi "AND"; then
    FUNCTIONS+=("AND")
fi
if echo "$USER_INPUT" | grep -qi "OR"; then
    FUNCTIONS+=("OR")
fi
if echo "$USER_INPUT" | grep -qi "XOR"; then
    FUNCTIONS+=("XOR")
fi
if echo "$USER_INPUT" | grep -qi "SLT"; then
    FUNCTIONS+=("SLT")
fi
if echo "$USER_INPUT" | grep -qi "zero"; then
    FUNCTIONS+=("ZERO_FLAG")
fi

echo "  检测到功能: ${FUNCTIONS[*]}"

# 3. 生成需求文档
echo "3. 生成需求文档..."
REQ_DOC="docs/requirements_${MODULE_NAME}.md"
{
    echo "# ${MODULE_NAME} 需求规格"
    echo "生成时间: $(date)"
    echo "原始需求: $USER_INPUT"
    echo ""
    echo "## 1. 模块概述"
    echo "- 模块名称: $MODULE_NAME"
    echo "- 功能描述: 基于用户自然语言需求生成的RISC-V模块"
    echo "- 标准: RV32I"
    echo ""
    echo "## 2. 功能需求"
    echo "### 2.1 支持的操作"
    for func in "${FUNCTIONS[@]}"; do
        echo "- $func"
    done
    echo ""
    echo "### 2.2 接口要求"
    echo "- 数据宽度: 32位"
    echo "- 时钟: 单时钟"
    echo "- 复位: 同步复位"
    echo "- 控制信号: 根据功能需求"
    echo ""
    echo "## 3. 性能要求"
    echo "- 工作频率: 100MHz"
    echo "- 延迟: 1周期"
    echo ""
    echo "## 4. 验证要求"
    echo "- 语法检查: Verilator lint检查"
    echo "- 功能验证: 完整测试套件"
    echo "- 报告格式: 符合作业要求"
} > "$REQ_DOC"

echo "  需求文档: $REQ_DOC"

# 4. 生成Chisel代码
echo "4. 生成Chisel代码..."
CHISEL_FILE="src/chisel/${MODULE_NAME}.scala"

if [ "$MODULE_NAME" = "ALU" ]; then
    # 生成ALU代码
    cat > "$CHISEL_FILE" << 'EOF'
package riscv

import chisel3._
import chisel3.util._

/**
  * RISC-V RV32I ALU模块
  * 支持ADD/SUB/AND/OR/XOR/SLT操作，包含zero标志位
  *
  * 接口符合RV32I标准
  */
class ALU extends Module {
  val io = IO(new Bundle {
    // 操作数输入
    val a = Input(UInt(32.W))
    val b = Input(UInt(32.W))

    // 操作码输入
    val alu_op = Input(UInt(4.W))

    // 结果输出
    val result = Output(UInt(32.W))

    // 标志位输出
    val zero = Output(Bool())
  })

  // 操作码定义
  val ALU_ADD = 0.U(4.W)
  val ALU_SUB = 1.U(4.W)
  val ALU_AND = 2.U(4.W)
  val ALU_OR  = 3.U(4.W)
  val ALU_XOR = 4.U(4.W)
  val ALU_SLT = 5.U(4.W)  // 有符号比较

  // 中间结果
  val add_result = io.a + io.b
  val sub_result = io.a - io.b
  val and_result = io.a & io.b
  val or_result  = io.a | io.b
  val xor_result = io.a ^ io.b

  // SLT: 有符号比较，如果 a < b 则结果为1，否则为0
  val slt_result = Mux(io.a.asSInt < io.b.asSInt, 1.U(32.W), 0.U(32.W))

  // 根据操作码选择结果
  io.result := MuxLookup(io.alu_op, 0.U(32.W), Seq(
    ALU_ADD -> add_result,
    ALU_SUB -> sub_result,
    ALU_AND -> and_result,
    ALU_OR  -> or_result,
    ALU_XOR -> xor_result,
    ALU_SLT -> slt_result
  ))

  // zero标志位：当结果为0时置位
  io.zero := io.result === 0.U
}

/**
  * ALU测试对象
  */
object ALU extends App {
  (new chisel3.stage.ChiselStage).emitVerilog(
    new ALU(),
    Array("--target-dir", "generated")
  )
}
EOF
    echo "  Chisel代码: $CHISEL_FILE"
else
    echo "  警告：暂不支持生成 $MODULE_NAME 的代码，使用示例代码"
    cp src/chisel/ALU.scala "$CHISEL_FILE"
fi

# 5. 编译Chisel代码
echo "5. 编译Chisel代码..."
COMPILE_LOG="sim/logs/compile_${MODULE_NAME}.log"
if command -v sbt &> /dev/null; then
    echo "  使用sbt编译..."
    sbt "runMain riscv.${MODULE_NAME}" 2>&1 | tee "$COMPILE_LOG"

    # 检查是否生成了FIRRTL文件
    if [ -f "generated/${MODULE_NAME}.v" ]; then
        cp "generated/${MODULE_NAME}.v" "src/verilog/"
        echo "  ✓ Verilog代码生成成功"
    else
        echo "  警告：sbt编译未生成Verilog，使用firtool"
        # 使用firtool直接转换
        if command -v firtool &> /dev/null; then
            echo "  使用firtool生成Verilog..."
            # 这里需要实际的FIRRTL文件，暂时跳过
            echo "  跳过Verilog生成（需要FIRRTL文件）"
        fi
    fi
else
    echo "  警告：sbt未安装，跳过编译"
fi

# 6. 生成测试平台
echo "6. 生成测试平台..."
TB_FILE="src/testbench/${MODULE_NAME}_tb.sv"

if [ "$MODULE_NAME" = "ALU" ]; then
    cp src/testbench/ALU_tb.sv "$TB_FILE"
    echo "  测试平台: $TB_FILE"
else
    echo "  警告：使用通用测试平台模板"
    cat > "$TB_FILE" << 'EOF'
`timescale 1ns/1ps

module ${MODULE_NAME}_tb;
  // 测试框架
  initial begin
    $display("=== ${MODULE_NAME} 测试开始 ===");
    // 添加具体测试内容
    #100;
    $display("RESULT: PASSED 0/0 tests (模板)");
    $finish;
  end
endmodule
EOF
    # 替换模块名
    sed -i "s/\${MODULE_NAME}/$MODULE_NAME/g" "$TB_FILE"
fi

# 7. 生成C++测试包装器
echo "7. 生成C++测试包装器..."
CPP_FILE="src/testbench/${MODULE_NAME}_tb.cpp"
cat > "$CPP_FILE" << EOF
#include "V${MODULE_NAME}.h"
#include "verilated.h"
#include <iostream>

int main(int argc, char** argv) {
    Verilated::commandArgs(argc, argv);

    V${MODULE_NAME}* dut = new V${MODULE_NAME};

    // 简单测试
    dut->reset = 1;
    dut->clock = 0;

    // 释放复位
    for (int i = 0; i < 5; i++) {
        dut->clock = !dut->clock;
        dut->eval();
    }
    dut->reset = 0;

    // 运行一些时钟周期
    for (int i = 0; i < 20; i++) {
        dut->clock = !dut->clock;
        dut->eval();
    }

    std::cout << "${MODULE_NAME} 仿真完成" << std::endl;

    delete dut;
    return 0;
}
EOF
echo "  C++测试: $CPP_FILE"

# 8. 执行验证流程
echo "8. 执行验证流程..."
if [ -f "sim/scripts/sim_${MODULE_NAME}.sh" ]; then
    echo "  使用现有仿真脚本..."
    bash "sim/scripts/sim_${MODULE_NAME}.sh"
else
    echo "  执行基本验证..."
    # 创建临时验证脚本
    VERIFY_SCRIPT="sim/scripts/verify_${MODULE_NAME}.sh"
    cat > "$VERIFY_SCRIPT" << EOF
#!/bin/bash
echo "=== ${MODULE_NAME} 基本验证 ==="
echo "1. 检查文件..."
ls -la src/chisel/${MODULE_NAME}.scala
ls -la src/testbench/${MODULE_NAME}_tb.sv
echo ""
echo "2. 验证完成"
echo "注：完整验证需要安装sbt、firtool、verilator等工具"
EOF
    chmod +x "$VERIFY_SCRIPT"
    bash "$VERIFY_SCRIPT"
fi

# 9. 生成最终报告
echo "9. 生成最终报告..."
FINAL_REPORT="docs/final_report_${MODULE_NAME}.md"
{
    echo "# ${MODULE_NAME} 自动生成报告"
    echo "生成时间: $(date)"
    echo ""
    echo "## 执行摘要"
    echo "- 用户需求: \`$USER_INPUT\`"
    echo "- 生成模块: $MODULE_NAME"
    echo "- 生成时间: $(date)"
    echo "- 状态: 完成"
    echo ""
    echo "## 生成文件"
    echo "### 源代码"
    echo "- 需求文档: \`docs/requirements_${MODULE_NAME}.md\`"
    echo "- Chisel代码: \`src/chisel/${MODULE_NAME}.scala\`"
    echo "- 测试平台: \`src/testbench/${MODULE_NAME}_tb.sv\`"
    echo "- C++测试: \`src/testbench/${MODULE_NAME}_tb.cpp\`"
    echo ""
    echo "### 验证文件"
    find sim/logs -name "*${MODULE_NAME}*" -type f | while read file; do
        echo "- $(basename "$file"): \`$file\`"
    done
    echo ""
    echo "## 下一步"
    echo "1. 安装完整工具链（sbt, firtool, verilator）"
    echo "2. 运行完整验证流程"
    echo "3. 根据需求调整生成的代码"
    echo ""
    echo "## 工具要求"
    echo "- Node.js 18+ 及 Claude Code CLI"
    echo "- Java 11+ 及 sbt"
    echo "- firtool（FIRRTL编译器）"
    echo "- Verilator >= 4.200"
} > "$FINAL_REPORT"

echo ""
echo "=== RTL自动生成完成 ==="
echo "生成模块: $MODULE_NAME"
echo "需求文档: $REQ_DOC"
echo "最终报告: $FINAL_REPORT"
echo ""
echo "使用以下命令进行完整验证："
echo "  cd $PROJECT_ROOT"
echo "  bash sim/scripts/sim_${MODULE_NAME}.sh"
echo ""
echo "注：这是一个演示版本，完整功能需要集成AI进行自然语言解析和代码生成。"