# RTL生成技能

## 技能概述
本技能用于指导AI自动生成RISC-V模块的RTL代码、测试平台和验证报告。当用户提出RTL生成需求时，自动触发此技能。

## 触发条件
- 用户输入包含"生成"、"RTL"、"ALU"、"寄存器"、"RISC-V"等关键词
- 用户明确要求生成硬件模块
- 用户描述RISC-V相关功能需求

## 执行步骤

### 步骤1：需求解析与澄清
**目标**：理解用户需求，生成规范化需求文档

**操作**：
1. 分析用户自然语言描述
2. 提取关键信息：
   - 模块名称
   - 功能列表
   - 接口要求
   - 性能要求
3. 如需求不明确，主动询问：
   - "请确认数据位宽（默认32位）"
   - "需要哪些控制信号？"
   - "有哪些特殊功能要求？"
4. 生成需求规格文档

**输出**：`docs/requirements_<模块名>.md`

### 步骤2：Chisel代码生成
**目标**：生成符合规范的Chisel代码

**操作**：
1. 根据需求规格设计模块架构
2. 生成Chisel源代码：
   - 包声明和导入
   - 模块类定义
   - IO接口定义
   - 内部逻辑实现
3. 确保代码符合RV32I标准
4. 添加适当注释

**输出**：`src/chisel/<模块名>.scala`

### 步骤3：编译与转换
**目标**：将Chisel编译为Verilog

**操作**：
1. 检查并创建必要的目录结构
2. 执行`sbt compile`编译Chisel代码
3. 使用`firtool`将FIRRTL转换为Verilog
4. 验证转换结果

**命令**：
```bash
# 进入项目目录
cd /home/loasic/EDA/作业1

# 编译Chisel
sbt "runMain chisel3.stage.ChiselMain --module <模块名> --target-dir target/firrtl"

# 转换FIRRTL为Verilog
firtool target/firrtl/<模块名>.fir \
  --lowering-options=disallowLocalVariables \
  -o src/verilog/<模块名>.v
```

**输出**：`src/verilog/<模块名>.v`

### 步骤4：语法检查
**目标**：检查生成的Verilog语法

**操作**：
1. 使用Verilator进行语法检查
2. 分析检查结果
3. 如发现ERROR，尝试修复
4. 记录WARNING信息

**命令**：
```bash
verilator --lint-only \
  --Wall \
  --Wno-style \
  src/verilog/<模块名>.v \
  2>&1 | tee sim/logs/lint_<模块名>.log
```

**输出**：`sim/logs/lint_<模块名>.log`

### 步骤5：Testbench生成
**目标**：生成功能测试平台

**操作**：
1. 根据模块功能设计测试用例
2. 生成SystemVerilog测试平台
3. 包含完整的测试激励
4. 添加结果检查机制

**测试用例类型**：
- 基本功能测试
- 边界测试
- 随机测试
- 错误情况测试

**输出**：
- `src/testbench/<模块名>_tb.sv`
- `sim/scripts/sim_<模块名>.sh`

### 步骤6：仿真验证
**目标**：执行仿真并验证功能

**操作**：
1. 编译仿真模型
2. 执行仿真
3. 收集仿真结果
4. 验证功能正确性

**命令**：
```bash
# 编译仿真模型
verilator --cc --exe --build \
  -j 0 \
  --trace \
  --assert \
  -Wall \
  -Wno-style \
  src/verilog/<模块名>.v \
  src/testbench/<模块名>_tb.cpp \
  -o sim_build/<模块名>_sim

# 执行仿真
./sim_build/<模块名>_sim 2>&1 | tee sim/logs/sim_<模块名>.log
```

**输出**：`sim/logs/sim_<模块名>.log`

### 步骤7：报告生成
**目标**：生成完整的验证报告

**操作**：
1. 汇总所有结果
2. 生成格式化报告
3. 包含：
   - 需求规格
   - 代码生成信息
   - 语法检查结果
   - 仿真结果
   - 性能统计

**报告格式**：
```markdown
# <模块名>验证报告

## 1. 需求规格
[需求描述]

## 2. 代码生成
- Chisel源码：src/chisel/<模块名>.scala
- Verilog源码：src/verilog/<模块名>.v

## 3. 语法检查结果
[检查结果摘要]

## 4. 仿真验证结果
[测试结果表格]

## 5. 总结
[通过/失败统计]
```

**输出**：`docs/verification_<模块名>.md`

## 错误处理

### 常见错误及处理
1. **编译错误**：
   - 检查Chisel语法
   - 验证导入语句
   - 检查依赖版本

2. **语法检查错误**：
   - 分析Verilator错误信息
   - 修复语法问题
   - 重新检查

3. **仿真失败**：
   - 检查测试激励
   - 验证接口连接
   - 调试时序问题

### 恢复机制
- 记录错误日志
- 提供修复建议
- 支持从失败步骤重新开始

## 性能优化

### 并行处理
- 语法检查和测试生成可并行执行
- 使用多核编译

### 缓存机制
- 缓存中间文件
- 避免重复计算

## 质量保证

### 代码质量
- 遵循编码规范
- 添加适当注释
- 模块化设计

### 测试覆盖
- 功能覆盖
- 边界条件覆盖
- 错误情况覆盖

### 文档完整性
- 完整的需求文档
- 详细的设计文档
- 全面的验证报告