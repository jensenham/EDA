#!/bin/bash
# 预提交钩子：在提交前自动执行语法检查和基本验证

echo "=== 预提交检查开始 ==="

# 检查当前目录
PROJECT_ROOT="/home/loasic/EDA/作业1"
cd "$PROJECT_ROOT" || exit 1

# 1. 检查是否有未完成的生成任务
echo "1. 检查未完成的任务..."
if [ -f ".claude/generation_in_progress" ]; then
    echo "  警告：有RTL生成任务正在进行中"
    read -p "  是否继续提交？(y/n): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

# 2. 检查Verilog文件语法
echo "2. 检查Verilog语法..."
VERILOG_FILES=$(find src/verilog -name "*.v" 2>/dev/null)
if [ -n "$VERILOG_FILES" ]; then
    for vfile in $VERILOG_FILES; do
        echo "  检查: $vfile"
        verilator --lint-only --Wall "$vfile" 2>&1 | grep -E "Error|ERROR" > /dev/null
        if [ $? -eq 0 ]; then
            echo "  错误：$vfile 存在语法错误"
            verilator --lint-only --Wall "$vfile" 2>&1 | grep -E "Error|ERROR"
            exit 1
        fi
    done
    echo "  所有Verilog文件语法检查通过"
else
    echo "  未找到Verilog文件，跳过语法检查"
fi

# 3. 检查必要的目录结构
echo "3. 检查目录结构..."
REQUIRED_DIRS=("src/chisel" "src/verilog" "src/testbench" "sim/logs" "docs")
for dir in "${REQUIRED_DIRS[@]}"; do
    if [ ! -d "$dir" ]; then
        echo "  创建目录: $dir"
        mkdir -p "$dir"
    fi
done

# 4. 检查构建文件
echo "4. 检查构建配置..."
if [ ! -f "build.sbt" ]; then
    echo "  错误：缺少build.sbt文件"
    exit 1
fi

# 5. 检查CLAUDE.md文件
echo "5. 检查项目文档..."
if [ ! -f "CLAUDE.md" ]; then
    echo "  警告：缺少CLAUDE.md文件"
fi

# 6. 检查测试文件完整性
echo "6. 检查测试文件..."
TESTBENCH_FILES=$(find src/testbench -name "*_tb.sv" 2>/dev/null)
if [ -n "$TESTBENCH_FILES" ]; then
    for tbfile in $TESTBENCH_FILES; do
        MODULE_NAME=$(basename "$tbfile" "_tb.sv")
        if [ ! -f "src/verilog/$MODULE_NAME.v" ]; then
            echo "  警告：测试平台 $tbfile 对应的Verilog文件不存在"
        fi
    done
fi

# 7. 生成状态报告
echo "7. 生成状态报告..."
{
    echo "# 项目状态报告"
    echo "生成时间: $(date)"
    echo ""
    echo "## 文件统计"
    echo "- Chisel文件: $(find src/chisel -name "*.scala" 2>/dev/null | wc -l)"
    echo "- Verilog文件: $(find src/verilog -name "*.v" 2>/dev/null | wc -l)"
    echo "- 测试平台: $(find src/testbench -name "*.sv" 2>/dev/null | wc -l)"
    echo "- 验证报告: $(find docs -name "verification_*.md" 2>/dev/null | wc -l)"
    echo ""
    echo "## 最近修改"
    git status --short 2>/dev/null || echo "未在git仓库中"
} > sim/logs/pre_commit_report.md

echo "=== 预提交检查完成 ==="
echo "详细报告见: sim/logs/pre_commit_report.md"

exit 0