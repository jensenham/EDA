#!/bin/bash
# 生成完成后钩子：自动执行验证和报告生成

echo "=== RTL生成完成，开始验证流程 ==="

# 检查参数
if [ $# -lt 1 ]; then
    echo "用法: $0 <模块名>"
    exit 1
fi

MODULE_NAME="$1"
PROJECT_ROOT="/home/loasic/EDA/作业1"
cd "$PROJECT_ROOT" || exit 1

# 1. 检查生成的文件
echo "1. 检查生成的文件..."
REQUIRED_FILES=(
    "src/chisel/$MODULE_NAME.scala"
    "src/verilog/$MODULE_NAME.v"
    "src/testbench/${MODULE_NAME}_tb.sv"
)

for file in "${REQUIRED_FILES[@]}"; do
    if [ ! -f "$file" ]; then
        echo "  错误：缺少文件 $file"
        exit 1
    else
        echo "  找到: $file"
    fi
done

# 2. 执行语法检查
echo "2. 执行Verilog语法检查..."
LINT_LOG="sim/logs/lint_${MODULE_NAME}.log"
verilator --lint-only \
    --Wall \
    --Wno-style \
    "src/verilog/$MODULE_NAME.v" \
    2>&1 | tee "$LINT_LOG"

# 检查语法错误
if grep -q -E "Error|ERROR" "$LINT_LOG"; then
    echo "  错误：发现语法错误"
    echo "  详细错误信息："
    grep -E "Error|ERROR" "$LINT_LOG"
    exit 1
else
    echo "  语法检查通过"
fi

# 3. 编译仿真模型
echo "3. 编译仿真模型..."
SIM_BUILD_DIR="sim_build/${MODULE_NAME}"
mkdir -p "$SIM_BUILD_DIR"

# 创建C++测试包装器
CPP_TB="src/testbench/${MODULE_NAME}_tb.cpp"
if [ ! -f "$CPP_TB" ]; then
    echo "  创建C++测试包装器..."
    cat > "$CPP_TB" << EOF
#include "V${MODULE_NAME}.h"
#include "verilated.h"
#include <iostream>
#include <cstdlib>

int main(int argc, char** argv) {
    Verilated::commandArgs(argc, argv);

    V${MODULE_NAME}* dut = new V${MODULE_NAME};

    // 初始化
    dut->reset = 1;
    dut->clock = 0;

    // 释放复位
    for (int i = 0; i < 10; i++) {
        dut->clock = !dut->clock;
        dut->eval();
    }
    dut->reset = 0;

    // 运行一些时钟周期
    for (int i = 0; i < 100; i++) {
        dut->clock = !dut->clock;
        dut->eval();
    }

    delete dut;

    std::cout << "仿真完成" << std::endl;
    return 0;
}
EOF
fi

# 编译
echo "  编译仿真模型..."
cd "$SIM_BUILD_DIR" && \
verilator --cc --exe \
    --trace \
    --assert \
    -Wall \
    -Wno-style \
    "../../src/verilog/$MODULE_NAME.v" \
    "../../src/testbench/${MODULE_NAME}_tb.cpp" \
    -o "${MODULE_NAME}_sim" \
    2>&1 | tee compile.log

if [ $? -ne 0 ]; then
    echo "  错误：编译失败"
    exit 1
fi

echo "  编译成功"

# 4. 执行仿真
echo "4. 执行仿真..."
SIM_LOG="../../sim/logs/sim_${MODULE_NAME}.log"
./"${MODULE_NAME}_sim" 2>&1 | tee "$SIM_LOG"

# 5. 生成验证报告
echo "5. 生成验证报告..."
VERIFICATION_REPORT="../../docs/verification_${MODULE_NAME}.md"

{
    echo "# ${MODULE_NAME} 验证报告"
    echo "生成时间: $(date)"
    echo ""
    echo "## 1. 模块信息"
    echo "- 模块名称: $MODULE_NAME"
    echo "- 生成时间: $(date)"
    echo ""
    echo "## 2. 文件清单"
    echo "- Chisel源码: \`src/chisel/$MODULE_NAME.scala\`"
    echo "- Verilog源码: \`src/verilog/$MODULE_NAME.v\`"
    echo "- 测试平台: \`src/testbench/${MODULE_NAME}_tb.sv\`"
    echo "- C++测试: \`src/testbench/${MODULE_NAME}_tb.cpp\`"
    echo ""
    echo "## 3. 语法检查结果"
    echo "### 检查命令"
    echo "\`\`\`bash"
    echo "verilator --lint-only --Wall --Wno-style src/verilog/$MODULE_NAME.v"
    echo "\`\`\`"
    echo ""
    echo "### 检查结果"
    if [ -f "../../$LINT_LOG" ]; then
        echo "检查日志摘要:"
        grep -E "Warning|WARNING|Error|ERROR" "../../$LINT_LOG" | head -20
        echo ""
        echo "详细日志见: \`$LINT_LOG\`"
    else
        echo "语法检查日志未找到"
    fi
    echo ""
    echo "## 4. 仿真验证结果"
    echo "### 仿真命令"
    echo "\`\`\`bash"
    echo "./sim_build/${MODULE_NAME}/${MODULE_NAME}_sim"
    echo "\`\`\`"
    echo ""
    echo "### 仿真结果"
    if [ -f "../../$SIM_LOG" ]; then
        echo "最后10行仿真输出:"
        tail -10 "../../$SIM_LOG"
        echo ""
        echo "完整日志见: \`$SIM_LOG\`"
    else
        echo "仿真日志未找到"
    fi
    echo ""
    echo "## 5. 总结"
    echo "- 语法检查: $(grep -q -E "Error|ERROR" "../../$LINT_LOG" && echo "失败" || echo "通过")"
    echo "- 仿真执行: $(grep -q "仿真完成" "../../$SIM_LOG" && echo "成功" || echo "失败")"
    echo "- 总体状态: $([ ! -s "../../$LINT_LOG" ] && grep -q "仿真完成" "../../$SIM_LOG" && echo "✅ 通过" || echo "❌ 失败")"
    echo ""
    echo "## 6. 下一步建议"
    if grep -q -E "Error|ERROR" "../../$LINT_LOG"; then
        echo "1. 修复语法错误"
        echo "2. 重新运行验证流程"
    elif ! grep -q "仿真完成" "../../$SIM_LOG"; then
        echo "1. 检查测试激励"
        echo "2. 调试仿真模型"
    else
        echo "1. 进行更全面的功能测试"
        echo "2. 添加性能测试"
        echo "3. 进行形式验证"
    fi
} > "$VERIFICATION_REPORT"

echo "6. 清理临时文件..."
# 保留重要文件，清理中间文件

echo "=== 验证流程完成 ==="
echo "验证报告: $VERIFICATION_REPORT"
echo "语法检查日志: $LINT_LOG"
echo "仿真日志: $SIM_LOG"

exit 0